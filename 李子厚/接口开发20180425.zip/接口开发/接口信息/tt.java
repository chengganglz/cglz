import java.math.BigDecimal;

/**
 * tt
 */
public class tt {

    public static ss name() {
        
    }
}